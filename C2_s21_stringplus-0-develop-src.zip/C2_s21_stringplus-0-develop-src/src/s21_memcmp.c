#include "s21_string.h"

int s21_memcmp(const void *str1, const void *str2, s21_size_t n) {
        s21_size_t i;
        unsigned char *array1;
        unsigned char *array2;
    if (n + 1 <= 0 || n == 0 || n + 1 < n)
        return (0);
    i = 0;
    array1 = (unsigned char *)str1;
    array2 = (unsigned char *)str2;
        if (!array1 && !array2 && !n)
            return (0);
    while (n--) {
        if (array1[i] != array2[i])
    return (array1[i] - array2[i]);
        i++;
    }
    return (0);
}
