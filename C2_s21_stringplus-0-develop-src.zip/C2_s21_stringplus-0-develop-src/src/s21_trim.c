#include "s21_string.h"

void *s21_trim(const char *src, const char *trim_chars) {
    int i;
    static char *buffer;
    buffer = malloc(s21_strlen(src));
    void *pt = NULL;
    s21_strcpy(buffer, src);
    for (i = s21_strlen(buffer) - 1; i >= 0 && s21_strchr(trim_chars, buffer[i]) != NULL; i--) {
        buffer[i] = '\0';
    }
    while (buffer[0] != '\0' && s21_strchr(trim_chars, buffer[0]) != NULL) {
        s21_memmove(&buffer[0], &buffer[1], s21_strlen(buffer));
    }
    pt = buffer;
    return pt;
}
