#include "s21_string.h"

s21_size_t s21_strlen(const char * p) {
  s21_size_t i = 0;
  for (; p[i]; i++) {}
  return i;
}
