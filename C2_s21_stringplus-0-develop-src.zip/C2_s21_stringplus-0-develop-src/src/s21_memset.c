#include "s21_string.h"

void *s21_memset(void *str, int c, s21_size_t n) {
    unsigned char *array;
    if (n == 0 || n + 1 <= 0 || n + 1 < n)
        return (str);
    array = (unsigned char *)str;
    while (n != 0) {
    *array++ = (unsigned char)c;
        n--;
    }
    return ((void *)str);
}
