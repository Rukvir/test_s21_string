#include "s21_string.h"

char *s21_strrchr(const char *str, int c) {
  char *i = s21_NULL;
    while (*str++) {
        if (*str == (char)c) {
            i = (char *)str;
        }
    }
    return i;
}
