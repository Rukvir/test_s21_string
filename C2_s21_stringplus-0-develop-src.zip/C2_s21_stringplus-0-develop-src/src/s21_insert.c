#include "s21_string.h"

void *s21_insert(const char *src, const char *str, s21_size_t n) {
    static char *buf;
    void *pr = s21_NULL;
    int fg = 0;
    int ep = s21_strlen(src) + s21_strlen(str);
    if (s21_strlen(src) >= n) {
        buf = malloc(ep);
        for (int i = 0; i < n; i++) {
            buf[i] = src[i];
            fg++;
        }
        for (int i = n; i < ep + n; i++) {
            buf[i] = str[i - n];
        }
        for (int i = s21_strlen(str) + fg; i < ep + n; i++) {
            buf[i] = src[i - s21_strlen(str)];
        }
        buf[ep] = '\0';
        pr = (void*)buf;
    }
    return pr;
}
