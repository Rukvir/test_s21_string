#include "s21_string.h"

char * s21_strtok(char * str1, const char * delim) {
  int i = 0;
  while (str1[i] != '\0') {
    for (int j = 0; j < (int)s21_strlen(delim); j++) {
      if (str1[i] == delim[j]) {
        str1[i] = '\0';
      }
    }
    i++;
  }
  if (*str1 == '\0') {
    return s21_NULL;
    } else {
      return str1;
    }
}
